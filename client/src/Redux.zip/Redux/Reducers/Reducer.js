import SetMenuItems from './Menu';

import { combineReducers } from 'redux';

const rootReducer = combineReducers(
    {
        SetMenuItems
    }
)

export default rootReducer;