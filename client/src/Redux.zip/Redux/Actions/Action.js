export const MenuItems = ( url ) => {

    return {
        type: "SETMENUITEMS",
        payload: {
            url: url
        }
    }

}